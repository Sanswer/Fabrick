package com.fabrick.esercizio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsercizioApplicationTests {

	@Test
	void contextLoads() {
	}

}
